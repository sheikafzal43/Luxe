-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2025 at 09:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `luxe`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$9wSoJOLl/./Xio887HmMX.Zc3AnHYNDHCjduLWVW3lry5ujGeaXxu');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `status` enum('Pending','Confirmed','Declined') DEFAULT 'Pending',
  `ordered_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `status`, `ordered_at`) VALUES
(8, 11, 8, 2, 'Confirmed', '2025-05-24 10:12:21'),
(9, 11, 13, 2, 'Confirmed', '2025-05-24 10:12:21'),
(10, 11, 17, 1, 'Confirmed', '2025-05-24 10:12:47'),
(11, 11, 9, 1, 'Pending', '2025-05-25 06:04:12');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` enum('Men','Women') NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `category`, `description`, `image`) VALUES
(8, 'Azzaro', 50.00, 'Men', 'Azzaro The Most Wanted EDP Intense For Men 100ML', '6831932494557_Azzaro-The-Most-Wanted-EDP-Intense-For-Men-100ML-1731387705924.webp'),
(9, 'Viktor&Rolf', 100.00, 'Men', 'Viktor & Rolf Spicebomb Extreme EDP For Men 90ML', '683193ab0aa44_Viktor-Rolf-Spicebomb-Extreme-EDP-For-Men-90ML-1731390079117.webp'),
(10, 'Tom Ford', 259.00, 'Men', 'Tom Ford Ombre Leather EDP For Unisex 100ML', '6831942ee8674_Tom-Ford-Ombre-Leather-EDP-For-Unisex-100ML-1731389938662.webp'),
(11, 'Chanel', 125.00, 'Men', 'Chanel Bleu De Chanel EDP For Men 100ML', '683195152fe4b_Chanel-Bleu-De-Chanel-EDP-For-Men-100ML-1731396702062.webp'),
(12, 'Carolina Herrera', 285.00, 'Men', 'CH 212 EDT For Men 100ML', '683195a76c66e_CH-212-EDT-For-Men-100ML-1731396404093.webp'),
(13, 'Creed', 1038.00, 'Men', 'Creed Green Irish Tweed EDP For Men 100ML', '6831960fecb79_Creed-Aventus-Absolu-EDP-For-Men-75ML-1731396954570.webp'),
(14, 'Dior', 235.00, 'Women', 'Dior Miss Dior Parfum EDP For Women 80ML', '683199bf51fe2_miss_dior.webp'),
(15, 'Dior', 515.00, 'Women', 'Dior Fahrenheit EDT For Men 100ML', '683199ffe08a7_Dior-Fahrenheit-EDT-For-Men-100ML-1731388136499.webp'),
(16, 'Dior', 590.00, 'Women', 'Dior Homme Intense EDP For Men 100ML', '68319a4d63ef4_Dior-Homme-Intense-EDP-For-Men-100ML-1731388138367.webp'),
(17, 'Holy Oud', 245.00, 'Women', 'Holy Oud Imperial Valley EDP Unisex 100ML', '68319ab5c1698_Holy-Oud-Imperial-Valley-Eau-De-Parfum-100ML-1731388974870.webp'),
(18, 'Holy Oud', 149.00, 'Women', 'Holy Oud Le Rose EDP Unisex 100ML', '68319ae34deef_Holy-Oud-Le-Rose-EDP-For-Unisex-100ML-1731388985783.webp'),
(19, 'Holy Oud', 150.00, 'Women', 'Holy Oud Expression EDP For Unisex 110ML', '68319b189ab41_holy-oud-expression-edp-for-unisex-110ml.webp');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(6, 'Afzal', 'a@gmail.com', '$2y$10$x4KPCokyKbvA7l/SKPbYI./epZu2LYsbWQI5JiAjkAbaGacCW6CJG', '2025-05-15 11:33:58'),
(7, 'Afzal', 'ss@gmail.com', '$2y$10$qYzvnsZjzatwmYrFe8GAAuJx9CDPlBtEzcRFyeiJ3Yvuam4ottZQm', '2025-05-16 05:11:02'),
(9, 'Chethmina', 'gamagechethmina2004@gmail.com', '$2y$10$xJ0P.8d23LKzwuQ7p/8Xuu50ZA4sRciZOViM3gp9M01I04lw.RpBa', '2025-05-23 10:04:27'),
(11, 'Testing', 'afzalsheik640@gmail.com', '$2y$10$JC6Ztu0sh6JximJgovdMguGXXEZpjCunGoZk8DnSBgy1LuDuz/Whi', '2025-05-24 05:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `added_at`) VALUES
(9, 11, 10, '2025-05-24 17:17:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
