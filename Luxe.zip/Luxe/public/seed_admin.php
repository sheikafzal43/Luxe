<?php
$pdo = new PDO("mysql:host=localhost;dbname=luxe", "root", "");
$hashed = password_hash("1234", PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
$stmt->execute(["admin", $hashed]);
echo "Admin inserted.";
