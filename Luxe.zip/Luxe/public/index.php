<?php
session_start();

require_once __DIR__ . '/../config/database.php';

// Load Controllers
require_once __DIR__ . '/../src/controller/HomeController.php';
require_once __DIR__ . '/../src/controller/AdminAuthController.php';
require_once __DIR__ . '/../src/controller/ProductController.php';
require_once __DIR__ . '/../src/controller/UserController.php';
require_once __DIR__ . '/../src/controller/CartController.php';
require_once __DIR__ . '/../src/controller/WishlistController.php';
require_once __DIR__ . '/../src/controller/OrderController.php';
require_once __DIR__ . '/../src/controller/DashboardController.php';

// ✅ Handle logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header("Location: index.php?page=home");
    exit;
}

// Route Parameters
$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? null;

$controller = new ProductController($pdo); // Default product controller

switch ($page) {
    // ---------- PUBLIC PAGES ----------
    case 'home':
        $homeController = new HomeController($pdo);
        $homeController->showLandingPage();
        break;

    case 'men':
        $controller->showMenProducts();
        break;

    case 'women':
        $controller->showWomenProducts();
        break;

    case 'productDetail':
        if (isset($_GET['id'])) {
            $controller->showDetailPage($_GET['id']);
        } else {
            echo "<p>Product ID is missing.</p>";
        }
        break;

    case 'brands':
        require __DIR__ . '/../src/view/customer/brand.php';
        break;

    case 'about':
        require __DIR__ . '/../src/view/customer/aboutus.php';
        break;

    // ---------- CART ----------
    case 'cart':
        $cartController = new CartController($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
            $cartController->add($_POST['product_id']);
        } elseif ($action === 'remove' && isset($_GET['id'])) {
            $cartController->remove($_GET['id']);
        } else {
            $cartController->showCart();
        }
        break;

    // ---------- WISHLIST ----------
    case 'wishlist':
        $wishlistController = new WishlistController($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
            $wishlistController->add($_POST['product_id']);
        } elseif ($action === 'remove' && isset($_GET['id'])) {
            $wishlistController->remove($_GET['id']);
        } else {
            $wishlistController->show();
        }
        break;

    // ---------- CHECKOUT & ORDERS ----------
    case 'checkout':
        $orderController = new OrderController($pdo);
        $orderController->checkout();
        break;

    case 'myOrders':
        $orderController = new OrderController($pdo);
        if ($action === 'remove' && isset($_GET['id'])) {
            $orderController->remove($_GET['id']);
        } else {
            $orderController->showOrders();
        }
        break;

    // ---------- CUSTOMER AUTH ----------
    case 'customerRegister':
        $userController = new UserController($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userController->registerUser($_POST);
        } else {
            $userController->showRegisterForm();
        }
        break;

    case 'customerLogin':
        $userController = new UserController($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userController->loginUser($_POST);
        } else {
            $userController->showLoginForm();
        }
        break;

    case 'customerLanding':
        if (!isset($_SESSION['user'])) {
            header("Location: index.php?page=customerLogin");
            exit;
        }
        require __DIR__ . '/../src/view/customer/landing.php';
        break;

    case 'profile':
        $userController = new UserController($pdo);
        $userController->showDashboard();
        break;

    case 'changePassword':
        $userController = new UserController($pdo);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userController->changePassword($_POST);
        } else {
            $userController->showChangePasswordForm();
        }
        break;

    // ---------- ADMIN AUTH ----------
    case 'adminLogin':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
            $authController = new AdminAuthController($pdo);
            $authController->login($_POST['username'], $_POST['password']);
            exit;
        }
        require_once __DIR__ . '/../src/view/admin/a_login.php';
        break;

    // ---------- ADMIN PROTECTED ROUTES ----------
    case 'adminDashboard':
        if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
            header("Location: index.php?page=adminLogin");
            exit;
        }
        $dashboardController = new DashboardController($pdo);
        $dashboardController->showDashboard();
        break;

    case 'adminProducts':
        if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
            header("Location: index.php?page=adminLogin");
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($action === 'add') {
                $controller->addProduct($_POST, $_FILES);
            } elseif ($action === 'update' && isset($_GET['id'])) {
                $controller->updateProduct($_GET['id'], $_POST, $_FILES);
            }
        } else {
            if ($action === 'edit' && isset($_GET['id'])) {
                $controller->editProduct($_GET['id']);
            } elseif ($action === 'delete' && isset($_GET['id'])) {
                $controller->deleteProduct($_GET['id']);
            } else {
                $controller->showManageProductsPage();
            }
        }
        break;

    case 'adminUsers':
        if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
            header("Location: index.php?page=adminLogin");
            exit;
        }
        $userController = new UserController($pdo);
        if ($action === 'delete' && isset($_GET['id'])) {
            $userController->deleteUser($_GET['id']);
        } else {
            $userController->showUserList();
        }
        break;

    case 'adminOrders':
        if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
            header("Location: index.php?page=adminLogin");
            exit;
        }
        $orderController = new OrderController($pdo);
        if ($action === 'update' && isset($_GET['id'], $_GET['status'])) {
            $orderController->updateStatus($_GET['id'], $_GET['status']);
        } else {
            $orderController->showAdminOrders();
        }
        break;

    case 'verify-otp':
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userController = new UserController($pdo);
        $userController->verifyOtp($_POST);
    } else {
        require_once __DIR__ . '/../src/view/customer/verify_otp.php';
    }
    break;


    // ---------- DEFAULT ----------
    default:
        echo "<h1>404 - Page Not Found</h1>";
        break;
}
