<?php
require_once __DIR__ . '/../model/ProductModel.php';

class ProductController {
    private $model;

    public function __construct($pdo) {
        $this->model = new ProductModel($pdo);
    }

    // ---------- ADMIN FUNCTIONS ----------

    public function showManageProductsPage() {
        $products = $this->model->getAllProducts();
        require __DIR__ . '/../view/admin/manage_products.php';
    }

    public function addProduct($data) {
        if (isset($data['name'], $data['price'], $data['description'], $data['category'])) {
            $this->model->addProduct($data);
        }
        header("Location: index.php?page=adminProducts");
        exit;
    }

    public function editProduct($id) {
        $product = $this->model->getProductById($id);
        if ($product) {
            require __DIR__ . '/../view/admin/edit_product.php';
        } else {
            header("Location: index.php?page=adminProducts&error=not_found");
            exit;
        }
    }

    public function updateProduct($id, $formData, $fileData) {
        $name = $formData['name'] ?? null;
        $price = $formData['price'] ?? null;
        $category = $formData['category'] ?? null;
        $description = $formData['description'] ?? null;

        if (!$name || !$price || !$category || !$description) {
            header("Location: index.php?page=adminProducts&error=missing_fields");
            exit;
        }

        $imageName = null;
        if (!empty($fileData['image']['name'])) {
            $imageName = basename($fileData['image']['name']);
            $targetDir = __DIR__ . '/../../public/uploads/';
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            move_uploaded_file($fileData['image']['tmp_name'], $targetDir . $imageName);
        }

        $this->model->updateProduct($id, $name, $price, $category, $description, $imageName);
        header("Location: index.php?page=adminProducts&success=updated");
        exit;
    }

    public function deleteProduct($id) {
        if ($id) {
            $this->model->deleteProduct($id);
        }
        header("Location: index.php?page=adminProducts&success=deleted");
        exit;
    }

    // ---------- CUSTOMER FUNCTIONS ----------

    public function showMenProducts() {
        $products = $this->model->getMenProducts();
        require __DIR__ . '/../view/customer/men.php';
    }

    public function showWomenProducts() {
        $products = $this->model->getWomenProducts();
        require __DIR__ . '/../view/customer/women.php';
    }

    public function showDetailPage($id) {
        $product = $this->model->getProductById($id);
        if ($product) {
            require __DIR__ . '/../view/customer/product_detail.php';
        } else {
            echo "<p class='text-red-500'>Product not found.</p>";
        }
    }
}
