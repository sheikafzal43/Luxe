<?php
require_once __DIR__ . '/../model/OrderModel.php';

class OrderController {
    private $model;

    public function __construct($pdo) {
        $this->model = new OrderModel($pdo);
    }

    // ✅ CUSTOMER: Place order and clear cart
    public function checkout() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Login to checkout'); window.location.href='index.php?page=customerLogin';</script>";
            return;
        }

        $user_id = $_SESSION['user']['id'];
        $this->model->placeOrderFromCart($user_id);
        header("Location: index.php?page=myOrders");
        exit;
    }

    // ✅ CUSTOMER: Show their own orders
    public function showOrders() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Login to view orders'); window.location.href='index.php?page=customerLogin';</script>";
            return;
        }

        $orders = $this->model->getUserOrders($_SESSION['user']['id']);
        require __DIR__ . '/../view/customer/my_orders.php';
    }

    // ✅ CUSTOMER: Remove a single order
    public function remove($id) {
        $this->model->removeOrder($id);
        header("Location: index.php?page=myOrders");
        exit;
    }

    // ✅ ADMIN: View all orders
    public function showAdminOrders() {
        $orders = $this->model->getAllOrders();
        require __DIR__ . '/../view/admin/manage_orders.php';
    }

    // ✅ ADMIN: Update status (e.g., to "Shipped", "Processing", "Cancelled")
    public function updateStatus($id, $status) {
        $this->model->updateOrderStatus($id, $status);
        header("Location: index.php?page=adminOrders");
        exit;
    }
}
