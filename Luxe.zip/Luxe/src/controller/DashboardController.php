<?php
require_once __DIR__ . '/../model/DashboardModel.php';

class DashboardController {
    private $model;

    public function __construct($pdo) {
        $this->model = new DashboardModel($pdo);
    }

    public function showDashboard() {
        $userCount = $this->model->getUserCount();
        $productCount = $this->model->getProductCount();
        $orderCount = $this->model->getOrderCount();
        $confirmedSales = $this->model->getConfirmedSalesTotal();

        require __DIR__ . '/../view/admin/dashboard.php';
    }
}
