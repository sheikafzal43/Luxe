<?php
class HomeController {
    public function showLandingPage() {
        require_once __DIR__ . '/../view/customer/landing.php';
    }
}
