<?php
require_once __DIR__ . '/../model/UserModel.php';

class UserController {
    private $model;
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->model = new UserModel($pdo);
    }

    // ---------- CUSTOMER FUNCTIONS ----------

    public function showRegisterForm() {
        require __DIR__ . '/../view/customer/register.php';
    }

    public function registerUser($data) {
        $name = trim($data['name']);
        $email = trim($data['email']);
        $password = trim($data['password']);

        if ($this->model->checkIfEmailExists($email)) {
            echo "<script>alert('Email already registered!'); window.location.href='index.php?page=customerRegister';</script>";
            return;
        }

        $this->model->registerUser($name, $email, $password);
        echo "<script>alert('Registration successful! Please login.'); window.location.href='index.php?page=customerLogin';</script>";
    }

    public function showLoginForm() {
        require __DIR__ . '/../view/customer/c_login.php';
    }

    public function loginUser($postData) {
        $email = trim($postData['email']);
        $password = trim($postData['password']);

        $user = $this->model->loginUser($email, $password);

        if ($user && password_verify($password, $user['password'])) {
            session_start();

            // Generate OTP and store in session
            $otp = rand(100000, 999999);
            $_SESSION['pending_user_id'] = $user['id'];
            $_SESSION['otp_code'] = $otp;
            $_SESSION['otp_expires'] = time() + 300;

            // Send OTP using PHPMailer (embedded)
            require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
            require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
            require_once __DIR__ . '/../PHPMailer/src/Exception.php';

            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'sheikafzal43@gmail.com';      // 👉 Replace with your Gmail
                $mail->Password = 'twei rtzo hhlx xluf';          // 👉 Replace with your App Password
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('sheikafzal43@gmail.com', 'Luxe Aromas');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body    = "<p>Your OTP is: <strong>$otp</strong></p><p>It expires in 5 minutes.</p>";

                $mail->send();
            } catch (\PHPMailer\PHPMailer\Exception $e) {
                echo "<script>alert('Email could not be sent: " . $mail->ErrorInfo . "');</script>";
                return;
            }

            header("Location: index.php?page=verify-otp");
            exit;
        } else {
            echo "<script>alert('Incorrect email or password'); window.location.href='index.php?page=customerLogin';</script>";
        }
    }

    public function verifyOtp($postData) {
        session_start();
        $enteredOtp = trim($postData['otp']);

        if (!isset($_SESSION['otp_code']) || time() > $_SESSION['otp_expires']) {
            echo "<script>alert('OTP expired. Please login again.'); window.location.href='index.php?page=customerLogin';</script>";
            return;
        }

        if ($enteredOtp == $_SESSION['otp_code']) {
            $userId = $_SESSION['pending_user_id'];
            $user = $this->model->getUserById($userId);

            $_SESSION['user'] = [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email']
            ];

            unset($_SESSION['otp_code'], $_SESSION['otp_expires'], $_SESSION['pending_user_id']);

            header("Location: index.php?page=home");
            exit;
        } else {
            echo "<script>alert('Incorrect OTP'); window.location.href='index.php?page=verify-otp';</script>";
        }
    }

    public function showDashboard() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Please log in first.'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $user = $this->model->getUserById($_SESSION['user']['id']);
        require __DIR__ . '/../view/customer/customer_dashboard.php';
    }

    public function showChangePasswordForm() {
        require __DIR__ . '/../view/customer/change_password.php';
    }

    public function changePassword($post) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $userId = $_SESSION['user']['id'];
        $current = $post['current_password'];
        $new = $post['new_password'];
        $confirm = $post['confirm_password'];

        $user = $this->model->getUserById($userId);

        if (!password_verify($current, $user['password'])) {
            echo "<script>alert('Current password is incorrect'); window.location.href='index.php?page=changePassword';</script>";
            return;
        }

        if ($new !== $confirm) {
            echo "<script>alert('New passwords do not match'); window.location.href='index.php?page=changePassword';</script>";
            return;
        }

        $hashedNewPassword = password_hash($new, PASSWORD_DEFAULT);
        $this->model->updatePassword($userId, $hashedNewPassword);

        echo "<script>alert('Password updated successfully!'); window.location.href='index.php?page=profile';</script>";
    }

    // ---------- ADMIN USER MANAGEMENT ----------

    public function showUserList() {
        $users = $this->model->getAllUsers();
        require __DIR__ . '/../view/admin/manage_users.php';
    }

    public function deleteUser($id) {
        $this->model->deleteUserById($id);
        header("Location: index.php?page=adminUsers");
        exit;
    }
}
