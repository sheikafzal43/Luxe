<?php
require_once __DIR__ . '/../model/CartModel.php';

class CartController {
    private $model;

    public function __construct($pdo) {
        $this->model = new CartModel($pdo);
    }

    // Add product to cart with quantity
    public function add($product_id) {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Please log in to add to cart'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $user_id = $_SESSION['user']['id'];
        $quantity = isset($_POST['quantity']) ? (int) $_POST['quantity'] : 1;

        $this->model->addToCart($user_id, $product_id, $quantity);
        header("Location: index.php?page=cart");
        exit;
    }

    // Show cart for current user
    public function showCart() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Please log in to view your cart'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $user_id = $_SESSION['user']['id'];
        $cartItems = $this->model->getUserCart($user_id);
        require __DIR__ . '/../view/customer/cart.php';
    }

    // Remove item from cart
    public function remove($cart_id) {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Please log in to remove from cart'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $this->model->removeFromCart($cart_id);
        header("Location: index.php?page=cart");
        exit;
    }
}
