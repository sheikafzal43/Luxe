<?php
class AdminAuthController {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function login($username, $password) {
        // Step 1: Fetch admin by username
        $stmt = $this->pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        // Step 2: Verify password (hashed)
        if ($admin && password_verify($password, $admin['password'])) {
            // Step 3: Start session if not already started
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }

            // Step 4: Set session
            $_SESSION['admin'] = true;
            $_SESSION['admin_username'] = $admin['username'];

            // Step 5: Redirect to dashboard
            header("Location: index.php?page=adminDashboard");
            exit;
        } else {
            echo "<script>alert('Invalid credentials'); window.location.href='index.php?page=adminLogin';</script>";
        }
    }
}
