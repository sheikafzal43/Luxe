<?php
require_once __DIR__ . '/../model/WishlistModel.php';

class WishlistController {
    private $model;

    public function __construct($pdo) {
        $this->model = new WishlistModel($pdo);
    }

    public function add($product_id) {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Login to use wishlist'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $user_id = $_SESSION['user']['id'];
        $this->model->addToWishlist($user_id, $product_id);
        header("Location: index.php?page=wishlist");
        exit;
    }

    public function remove($id) {
        $this->model->removeFromWishlist($id);
        header("Location: index.php?page=wishlist");
        exit;
    }

    public function show() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['user']['id'])) {
            echo "<script>alert('Login to view your wishlist'); window.location.href='index.php?page=customerLogin';</script>";
            exit;
        }

        $wishlistItems = $this->model->getUserWishlist($_SESSION['user']['id']);
        require __DIR__ . '/../view/customer/wishlist.php';
    }
}
