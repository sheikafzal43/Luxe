<?php
class WishlistModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Add to wishlist (avoids duplicate with INSERT IGNORE)
    public function addToWishlist($userId, $productId) {
        $stmt = $this->pdo->prepare("
            INSERT IGNORE INTO wishlist (user_id, product_id) 
            VALUES (?, ?)
        ");
        return $stmt->execute([$userId, $productId]);
    }

    // Get wishlist items for a user (joins products for detail view)
    public function getUserWishlist($userId) {
        $stmt = $this->pdo->prepare("
            SELECT 
                wishlist.id AS wishlist_id,
                products.id AS id,
                products.name,
                products.price,
                products.image
            FROM wishlist
            INNER JOIN products ON wishlist.product_id = products.id
            WHERE wishlist.user_id = ?
            ORDER BY wishlist.added_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Remove a product from wishlist by wishlist entry ID
    public function removeFromWishlist($wishlistId) {
        $stmt = $this->pdo->prepare("
            DELETE FROM wishlist 
            WHERE id = ?
        ");
        return $stmt->execute([$wishlistId]);
    }
}
