<?php
class CartModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Add product to cart with quantity
    public function addToCart($user_id, $product_id, $quantity) {
        $stmt = $this->pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
        return $stmt->execute([$user_id, $product_id, $quantity]);
    }

    // Get all items in user's cart
    public function getUserCart($user_id) {
        $stmt = $this->pdo->prepare("
            SELECT cart.id, products.name, products.price, products.image, cart.quantity
            FROM cart
            JOIN products ON cart.product_id = products.id
            WHERE cart.user_id = ?
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Remove product from cart
    public function removeFromCart($cart_id) {
        $stmt = $this->pdo->prepare("DELETE FROM cart WHERE id = ?");
        return $stmt->execute([$cart_id]);
    }
}
