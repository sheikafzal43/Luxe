<?php
class ProductModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Fetch all products
    public function getAllProducts() {
        $stmt = $this->pdo->query("SELECT * FROM products ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Add a new product
    public function addProduct($data) {
        $imageName = $this->handleImageUpload($_FILES['image']);

        $stmt = $this->pdo->prepare("INSERT INTO products (name, price, description, category, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['name'],
            $data['price'],
            $data['description'],
            $data['category'],
            $imageName
        ]);
    }

    // Get a product by ID
    public function getProductById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Update an existing product
    public function updateProduct($id, $name, $price, $category, $description, $newImage = null) {
        if ($newImage) {
            $stmt = $this->pdo->prepare("UPDATE products SET name = ?, price = ?, description = ?, category = ?, image = ? WHERE id = ?");
            $stmt->execute([$name, $price, $description, $category, $newImage, $id]);
        } else {
            $stmt = $this->pdo->prepare("UPDATE products SET name = ?, price = ?, description = ?, category = ? WHERE id = ?");
            $stmt->execute([$name, $price, $description, $category, $id]);
        }
    }

    // Delete a product
    public function deleteProduct($id) {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
    }

    // Handle image upload
    private function handleImageUpload($imageFile) {
        if ($imageFile['error'] === UPLOAD_ERR_OK && is_uploaded_file($imageFile['tmp_name'])) {
            $targetDir = __DIR__ . '/../../public/uploads/';
            $filename = uniqid() . '_' . basename($imageFile['name']);
            $targetPath = $targetDir . $filename;

            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }

            move_uploaded_file($imageFile['tmp_name'], $targetPath);
            return $filename;
        }

        return ''; // fallback if no file uploaded
    }

    // Fetch only Men's products
    public function getMenProducts() {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE category = 'Men'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch only Women's products
    public function getWomenProducts() {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE category = 'Women'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
