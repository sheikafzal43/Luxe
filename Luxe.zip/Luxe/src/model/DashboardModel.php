<?php
class DashboardModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getUserCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM users");
        return $stmt->fetchColumn();
    }

    public function getProductCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM products");
        return $stmt->fetchColumn();
    }

    public function getOrderCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM orders");
        return $stmt->fetchColumn();
    }

    // ✅ Fixed: Total sales = SUM(price * quantity) via JOIN
    public function getConfirmedSalesTotal() {
        $stmt = $this->pdo->query("
            SELECT SUM(p.price * o.quantity) AS total
            FROM orders o
            JOIN products p ON o.product_id = p.id
            WHERE o.status = 'Confirmed'
        ");
        return $stmt->fetchColumn() ?? 0;
    }
}
