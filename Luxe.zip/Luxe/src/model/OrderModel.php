<?php
class OrderModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Place order from cart
    public function placeOrderFromCart($user_id) {
        $cartItems = $this->pdo->prepare("SELECT * FROM cart WHERE user_id = ?");
        $cartItems->execute([$user_id]);
        $items = $cartItems->fetchAll(PDO::FETCH_ASSOC);

        $insert = $this->pdo->prepare("INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)");

        foreach ($items as $item) {
            $insert->execute([$user_id, $item['product_id'], $item['quantity']]);
        }

        $clearCart = $this->pdo->prepare("DELETE FROM cart WHERE user_id = ?");
        $clearCart->execute([$user_id]);
    }

    // Get all orders by user (for user dashboard)
    public function getUserOrders($user_id) {
        $stmt = $this->pdo->prepare("
            SELECT orders.id, products.name, products.image, products.price, orders.quantity, orders.status, orders.ordered_at
            FROM orders
            JOIN products ON orders.product_id = products.id
            WHERE orders.user_id = ?
            ORDER BY orders.ordered_at DESC
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Remove an order (user or admin)
    public function removeOrder($order_id) {
        $stmt = $this->pdo->prepare("DELETE FROM orders WHERE id = ?");
        return $stmt->execute([$order_id]);
    }

    // ✅ Get all orders (for admin panel)
    public function getAllOrders() {
        $stmt = $this->pdo->prepare("
            SELECT orders.id, users.name AS customer_name, products.name AS product_name,
                   products.image, orders.quantity, orders.status, orders.ordered_at
            FROM orders
            JOIN users ON orders.user_id = users.id
            JOIN products ON orders.product_id = products.id
            ORDER BY orders.ordered_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ✅ Update order status (for admin actions)
    public function updateOrderStatus($id, $status) {
        $stmt = $this->pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }
}
