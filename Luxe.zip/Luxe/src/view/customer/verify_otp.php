<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Verify OTP - Luxe Aromas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
  <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md space-y-6">
    <h2 class="text-2xl font-bold text-center">Enter OTP</h2>
    <form action="index.php?page=verify-otp" method="POST" class="space-y-4">
      <input
        type="text"
        name="otp"
        placeholder="Enter the 6-digit code"
        class="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-black"
        required
      >
      <button
        type="submit"
        class="w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition duration-200"
      >
        Verify OTP
      </button>
    </form>
  </div>
</body>
</html>
