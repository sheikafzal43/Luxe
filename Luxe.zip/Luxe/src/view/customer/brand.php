<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Brands - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 text-gray-900 font-sans">

  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <main class="max-w-7xl mx-auto px-6 py-12">
    <h1 class="text-3xl font-bold text-center mb-10">Our Signature Brands</h1>

    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
      <?php
        $brands = [
          "Creed", "Chanel", "Tom Ford", "Dior",
          "Carolina Herrera", "Louis Vuitton", "Azzaro", "Versace",
          "Yves Saint Laurent", "Armani", "Givenchy", "Paco Rabanne",
          "Jo Malone", "Bvlgari", "Viktor & Rolf", "Calvin Klein",
          "Dolce & Gabbana", "Burberry", "Gucci", "Ralph Lauren"
        ];

        foreach ($brands as $brand): ?>
          <div class="brand-box">
            <i class="fas fa-gem brand-icon"></i>
            <p class="brand-name"><?= htmlspecialchars($brand) ?></p>
          </div>
      <?php endforeach; ?>
    </div>
  </main>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>