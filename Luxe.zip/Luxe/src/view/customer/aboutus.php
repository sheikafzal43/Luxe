<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>About Us - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-white text-gray-800 font-sans">

  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <main class="max-w-7xl mx-auto px-6 py-16 space-y-20">

    <!-- Title -->
    <section class="text-center">
      <h1 class="text-4xl font-bold mb-4 animate-fade-in-down">About us</h1>
      <p class="text-gray-600 max-w-2xl mx-auto animate-fade-in">
        At <strong>Luxe Aromas</strong>, we don’t just sell perfumes—we craft timeless expressions of elegance. Our mission is to elevate your identity through luxurious fragrances tailored for individuality and prestige.
      </p>
    </section>

    <!-- Section 1 -->
    <section class="grid grid-cols-1 md:grid-cols-2 gap-10 items-center animate-slide-in-left">
      <img src="/LUXE/public/images/6.jpg" alt="Luxury Perfume Display" class="rounded-lg shadow-md hover:scale-105 transition-transform duration-300">
      <div>
        <h3 class="text-xl font-semibold mb-2 text-[#0F172A]">Curated Luxury for Every Mood</h3>
        <p class="text-gray-600">
          Our globally sourced fragrances are handpicked for those who demand sophistication. From signature scents to rare finds, we bring elegance to your everyday rituals.
        </p>
      </div>
    </section>

    <!-- Section 2 -->
    <section class="grid grid-cols-1 md:grid-cols-2 gap-10 items-center animate-slide-in-right">
      <div>
        <h3 class="text-xl font-semibold mb-2 text-[#0F172A]">Elevating Every Experience</h3>
        <p class="text-gray-600">
          We believe a great scent turns heads and sparks memories. Luxe Aromas is trusted by thousands for our curated excellence, premium sourcing, and artisanal approach.
        </p>
      </div>
      <img src="/LUXE/public/images/5.jpg" alt="Chanel Perfume" class="rounded-lg shadow-md hover:scale-105 transition-transform duration-300">
    </section>

    <!-- Contact + Form -->
    <section class="grid grid-cols-1 md:grid-cols-2 gap-10 animate-fade-in">
      <!-- Contact Info -->
      <div class="space-y-6">
        <h4 class="text-lg font-bold text-[#0F172A]">Get in touch with us</h4>
        <div>
          <p><strong>Address:</strong><br> 25th Floor, Prestige Plaza, Beverly Hills, CA</p>
        </div>
        <div>
          <p><strong>Email:</strong><br> support@luxearomas.com</p>
        </div>
        <div>
          <p><strong>Phone:</strong><br> +1 (800) 123-4567</p>
        </div>
        <div class="flex gap-4 mt-2 text-xl text-gray-700">
          <i class="fab fa-facebook hover:text-blue-600"></i>
          <i class="fab fa-instagram hover:text-pink-500"></i>
          <i class="fab fa-youtube hover:text-red-500"></i>
          <i class="fab fa-twitter hover:text-blue-400"></i>
        </div>
      </div>

      <!-- Contact Form -->
      <form class="space-y-6">
        <div>
          <label class="block text-sm font-medium">Full Name</label>
          <input type="text" class="w-full border px-4 py-2 rounded mt-1 focus:ring-2 focus:ring-black">
        </div>
        <div>
          <label class="block text-sm font-medium">Email Address</label>
          <input type="email" class="w-full border px-4 py-2 rounded mt-1 focus:ring-2 focus:ring-black">
        </div>
        <div>
          <label class="block text-sm font-medium">Message</label>
          <textarea rows="4" class="w-full border px-4 py-2 rounded mt-1 focus:ring-2 focus:ring-black"></textarea>
        </div>
        <button type="submit" class="bg-black text-white px-6 py-2 rounded hover:bg-gray-800 transition duration-200">Send Message</button>
      </form>
    </section>
  </main>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
