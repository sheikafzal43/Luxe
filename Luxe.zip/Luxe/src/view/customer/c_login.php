<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Customer Login - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">

  <form action="index.php?page=customerLogin" method="POST" class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md space-y-6">
    <h2 class="text-2xl font-bold text-center">Customer Login</h2>

    <input type="email" name="email" placeholder="Email" class="w-full border p-2 rounded" required>
    <input type="password" name="password" placeholder="Password" class="w-full border p-2 rounded" required>

    <button type="submit" class="w-full bg-black text-white py-2 rounded">Login</button>

    <p class="text-center text-sm">Don't have an account? 
      <a href="index.php?page=customerRegister" class="text-blue-600 hover:underline">Register here</a>
    </p>
  </form>

</body>
</html>
