<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Orders - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-900">

  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <div class="flex">
    <?php include_once __DIR__ . '/../components/customer_sidebar.php'; ?>

    <main class="flex-1 max-w-6xl mx-auto px-6 py-12">
      <h1 class="text-3xl font-bold mb-6">My Orders</h1>

      <?php if (empty($orders)): ?>
        <p>You haven't placed any orders yet.</p>
      <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <?php foreach ($orders as $order): ?>
            <div class="bg-white shadow rounded p-4">
              <img src="uploads/<?= htmlspecialchars($order['image']) ?>" class="w-full h-40 object-contain mb-3">
              <h2 class="text-lg font-semibold"><?= htmlspecialchars($order['name']) ?></h2>
              <p class="text-sm">Qty: <?= $order['quantity'] ?></p>
              <p class="text-sm font-bold text-gray-700">$<?= number_format($order['price'], 2) ?></p>
              <p class="mt-2 text-sm font-medium 
                <?= $order['status'] === 'Pending' ? 'text-yellow-600' : ($order['status'] === 'Confirmed' ? 'text-green-600' : 'text-red-600') ?>">
                Status: <?= $order['status'] ?>
              </p>

              <?php if ($order['status'] !== 'Confirmed'): ?>
                <form action="index.php?page=myOrders&action=remove&id=<?= $order['id'] ?>" method="POST" class="mt-3">
                  <button type="submit" class="text-red-500 hover:underline">Remove</button>
                </form>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </main>
  </div>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
