<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Profile - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-900">

  <!-- ✅ Top Header -->
  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <!-- ✅ Layout: Sidebar + Content -->
  <div class="flex">
    <!-- Sidebar -->
    <?php include_once __DIR__ . '/../components/customer_sidebar.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-10">
      <section class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-bold mb-6">Welcome, <?= htmlspecialchars($user['name']) ?></h1>

        <div class="bg-white rounded shadow p-6 space-y-4">
          <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
          <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
          <p><strong>Member Since:</strong> <?= date('F j, Y', strtotime($user['created_at'])) ?></p>
        </div>
      </section>
    </main>
  </div>

</body>
</html>
