<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Cart - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-900">

  <!-- Header at the top -->
  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <!-- Sidebar + Content layout -->
  <div class="flex">
    <!-- Sidebar on the left -->
    <?php include_once __DIR__ . '/../components/customer_sidebar.php'; ?>

    <!-- Main content on the right -->
    <main class="flex-1 px-6 py-12">
      <h1 class="text-3xl font-bold mb-6">My Cart</h1>

      <div class="bg-white shadow rounded p-6 mb-6">
        <?php if (empty($cartItems)): ?>
          <p>Your cart is empty.</p>
        <?php else: ?>
          <table class="w-full text-sm">
            <thead>
              <tr class="border-b text-left">
                <th class="py-2">Image</th>
                <th class="py-2">Product</th>
                <th class="py-2">Price</th>
                <th class="py-2">Quantity</th>
                <th class="py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $total = 0;
                foreach ($cartItems as $item):
                  $itemTotal = $item['price'] * $item['quantity'];
                  $total += $itemTotal;
              ?>
                <tr class="border-b">
                  <td class="py-2">
                    <img src="uploads/<?= htmlspecialchars($item['image']) ?>" class="w-16 h-16 object-contain">
                  </td>
                  <td class="py-2"><?= htmlspecialchars($item['name']) ?></td>
                  <td class="py-2">$<?= number_format($item['price'], 2) ?></td>
                  <td class="py-2"><?= $item['quantity'] ?></td>
                  <td class="py-2">
                    <a href="index.php?page=cart&action=remove&id=<?= $item['id'] ?>" class="text-red-500 hover:underline">Remove</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>

          <div class="flex justify-between items-center mt-6">
            <p class="text-xl font-semibold">Total: $<?= number_format($total, 2) ?></p>
            <a href="index.php?page=checkout" class="inline-block bg-black text-white px-6 py-2 rounded hover:bg-gray-800">
              Checkout
            </a>
          </div>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
