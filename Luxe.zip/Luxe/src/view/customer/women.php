<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Women's Products</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-900">

  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <main class="max-w-6xl mx-auto px-6 py-12">
    <h1 class="text-3xl font-bold mb-8">Women's Products</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      <?php foreach ($products as $product): ?>
        <a href="index.php?page=productDetail&id=<?= $product['id'] ?>" class="block bg-white shadow rounded p-4 hover:shadow-lg transition">
          <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-48 object-contain mb-4">
          <h2 class="text-xl font-semibold"><?= htmlspecialchars($product['name']) ?></h2>
          <p class="text-sm text-gray-600"><?= htmlspecialchars($product['description']) ?></p>
          <p class="mt-2 font-bold text-lg">$<?= number_format($product['price'], 2) ?></p>
        </a>
      <?php endforeach; ?>
    </div>
  </main>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
