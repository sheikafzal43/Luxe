<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
if (!isset($_SESSION['user'])) {
  header("Location: index.php?page=customerLogin");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Change Password - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 text-gray-900 font-sans">

<div class="flex">
  <?php include_once __DIR__ . '/../components/customer_sidebar.php'; ?>

  <main class="flex-1 max-w-3xl p-12">
    <h2 class="text-3xl font-bold mb-8">Change Password</h2>

    <form method="POST" action="index.php?page=changePassword" class="bg-white p-8 rounded shadow space-y-6 max-w-xl">
      <div>
        <label class="block text-gray-700 mb-1">Current Password</label>
        <input type="password" name="current_password" required class="w-full px-4 py-2 border rounded-md">
      </div>

      <div>
        <label class="block text-gray-700 mb-1">New Password</label>
        <input type="password" name="new_password" required class="w-full px-4 py-2 border rounded-md">
      </div>

      <div>
        <label class="block text-gray-700 mb-1">Confirm New Password</label>
        <input type="password" name="confirm_password" required class="w-full px-4 py-2 border rounded-md">
      </div>

      <button type="submit" class="bg-black text-white px-6 py-2 rounded hover:bg-gray-800">
        Update Password
      </button>
    </form>
  </main>
</div>

</body>
</html>
