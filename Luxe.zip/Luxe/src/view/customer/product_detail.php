<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($product['name']) ?> - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>

<body class="bg-gray-100 text-gray-900">
  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <main class="max-w-6xl mx-auto px-6 py-12">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-10 bg-white p-6 rounded shadow">
      <div>
        <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= $product['name'] ?>" class="w-full h-auto object-contain">
      </div>
      <div>
        <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($product['name']) ?></h1>
        <p class="text-gray-600 mb-4"><?= htmlspecialchars($product['description']) ?></p>
        <p class="text-2xl font-semibold mb-6">$<?= number_format($product['price'], 2) ?></p>

        <!-- Add to Cart -->
        <?php if (isset($_SESSION['user'])): ?>
          <form action="index.php?page=cart&action=add" method="POST" class="mb-4 space-y-3">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">

            <div>
              <label for="quantity" class="block font-medium mb-1">Quantity:</label>
              <input type="number" name="quantity" id="quantity" min="1" value="1" class="w-24 p-2 border rounded">
            </div>

            <button type="submit" class="bg-black text-white px-6 py-2 rounded hover:bg-gray-800">
              Add to Cart
            </button>
          </form>
        <?php else: ?>
          <a href="index.php?page=customerLogin" class="bg-gray-300 text-gray-600 px-6 py-2 rounded block text-center mb-4">
            Login to Add to Cart
          </a>
        <?php endif; ?>

        <!-- Add to Wishlist -->
        <?php if (isset($_SESSION['user'])): ?>
          <form action="index.php?page=wishlist&action=add" method="POST">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <button type="submit" class="mt-3 border border-black text-black px-6 py-2 rounded hover:bg-black hover:text-white">
              Add to Wishlist
            </button>
          </form>
        <?php else: ?>
          <a href="index.php?page=customerLogin" class="mt-3 inline-block border border-gray-300 text-gray-600 px-6 py-2 rounded">
            Login to Add to Wishlist
          </a>
        <?php endif; ?>

      </div>
    </div>
  </main>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
