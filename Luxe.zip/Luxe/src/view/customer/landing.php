<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Luxe Aromas - Home</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>

<body class="font-sans text-gray-800">
  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <!-- Hero Section -->
  <section class="bg-[#f7f5f2] py-20">
    <div class="container mx-auto px-6 flex flex-col-reverse md:flex-row items-center">
      <div class="w-full md:w-1/2 text-center md:text-left">
        <p class="text-lg mb-2">Starting from: $49.99</p>
        <h1 class="text-4xl font-bold mb-4">Exclusive collection for everyone</h1>
        <a href="index.php?page=men" class="inline-block bg-black text-white px-6 py-3 rounded-full mt-4">
          Explore now <i class="fas fa-search ml-2"></i>
        </a>
      </div>
      <div class="w-full md:w-1/2 mb-8 md:mb-0">
        <img src="/LUXE/public/images/p.png" alt="Perfume Bottle" class="mx-auto w-60">
      </div>
    </div>
  </section>

  <!-- Feature Icons -->
  <section class="bg-white py-8">
    <div class="container mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
      <div>
        <i class="fas fa-shipping-fast text-xl mb-2"></i>
        <p class="font-semibold">Free shipping</p>
        <p class="text-sm">On orders over $50.00</p>
      </div>
      <div>
        <i class="fas fa-phone text-xl mb-2"></i>
        <p class="font-semibold">Very easy to return</p>
        <p class="text-sm">Just phone number</p>
      </div>
      <div>
        <i class="fas fa-globe text-xl mb-2"></i>
        <p class="font-semibold">Worldwide delivery</p>
        <p class="text-sm">Fast delivery worldwide</p>
      </div>
      <div>
        <i class="fas fa-undo text-xl mb-2"></i>
        <p class="font-semibold">Refunds policy</p>
        <p class="text-sm">60 days return for any reason</p>
      </div>
    </div>
  </section>

  <!-- Shop by Category -->
  <section class="py-10">
    <div class="container mx-auto px-6 text-center">
      <h2 class="text-xl font-semibold mb-4">Start exploring. <span class="text-gray-500">Good things are waiting for you</span></h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
        <a href="index.php?page=men" class="border p-4 rounded shadow hover:shadow-lg">
          <p class="font-semibold">For Men's</p>
          <p class="text-sm">Starting at $24</p>
        </a>
        <a href="index.php?page=women" class="border p-4 rounded shadow hover:shadow-lg">
          <p class="font-semibold">For Women's</p>
          <p class="text-sm">Starting at $19</p>
        </a>
        <a href="index.php?page=brands" class="border p-4 rounded shadow hover:shadow-lg">
          <p class="font-semibold">Brands</p>
          <p class="text-sm">Explore brands</p>
        </a>
      </div>
    </div>
  </section>

  <!-- Full-Width Promotional Video Section -->
  <section class="py-12 bg-gray-100">
    <div class="w-full text-center mb-6">
      <h2 class="text-2xl font-bold mb-2">Discover the Essence of Luxury</h2>
      <p class="text-gray-600">Watch our signature fragrance collection in action</p>
    </div>
    <div class="w-full">
      <video class="w-full h-[700px] object-cover" autoplay muted loop playsinline>
      <source src="/LUXE/public/images/1.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
  </section>

  <!-- Image Promotional Banner -->
  <section class="py-16 bg-white">
    <div class="container mx-auto px-6 flex flex-col-reverse md:flex-row items-center bg-gray-50 rounded-xl shadow-lg overflow-hidden">
      <div class="w-full md:w-1/2 p-8 md:pl-12 text-center md:text-left">
        <p class="text-sm text-gray-500 font-medium mb-2">100% Original Products</p>
        <h2 class="text-3xl md:text-4xl font-bold mb-4">The All New Luxury Perfume Collection</h2>
        <p class="text-lg text-gray-700 mb-6">Starting from: <span class="font-semibold">$59.99</span></p>
        <a href="index.php?page=women" class="inline-block bg-black text-white px-6 py-3 rounded-full shadow-md hover:bg-gray-900 transition">
          Shop now
        </a>
      </div>
      <div class="w-full md:w-1/2">
        <img src="/LUXE/public/images/3.png" alt="Perfume Banner" class="w-full h-auto object-cover">
      </div>
    </div>
  </section>

  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
