<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Wishlist - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-900">

  <!-- Header at top -->
  <?php include_once __DIR__ . '/../components/header.php'; ?>

  <!-- Sidebar + Content -->
  <div class="flex">
    <!-- Sidebar -->
    <?php include_once __DIR__ . '/../components/customer_sidebar.php'; ?>

    <!-- Main content -->
    <main class="flex-1 px-6 py-12">
      <h1 class="text-3xl font-bold mb-6">My Wishlist</h1>

      <?php if (empty($wishlistItems)): ?>
        <p>Your wishlist is empty.</p>
      <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <?php foreach ($wishlistItems as $item): ?>
            <div class="bg-white shadow rounded p-4 hover:shadow-md transition">
              <!-- Product link -->
              <a href="index.php?page=productDetail&id=<?= $item['id'] ?>" class="block hover:opacity-90">
                <img src="uploads/<?= htmlspecialchars($item['image']) ?>" class="w-full h-48 object-contain mb-4">
                <h2 class="text-xl font-semibold hover:underline"><?= htmlspecialchars($item['name']) ?></h2>
                <p class="text-lg font-bold mt-2">$<?= number_format($item['price'], 2) ?></p>
              </a>

              <!-- Remove button (uses wishlist_id) -->
              <form action="index.php?page=wishlist&action=remove&id=<?= $item['wishlist_id'] ?>" method="POST" class="mt-3">
                <button type="submit" class="text-red-500 hover:underline">Remove</button>
              </form>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </main>
  </div>

  <!-- Footer -->
  <?php include_once __DIR__ . '/../components/footer.php'; ?>
</body>
</html>
