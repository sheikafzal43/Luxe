<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/d126f19daa.js" crossorigin="anonymous"></script>

</head>
<body>
  
</body>
</html>

<footer class="bg-white border-t border-gray-200 text-gray-700">
  <div class="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-10 text-sm">

    <!-- Branding & Social -->
    <div>
      <h1 class="text-2xl font-extrabold mb-4 text-black">LUXE AROMAS</h1>
      <ul class="space-y-2">
        <li class="flex items-center space-x-2"><i class="fab fa-facebook-f text-blue-600"></i> <span>Facebook</span></li>
        <li class="flex items-center space-x-2"><i class="fab fa-youtube text-red-600"></i> <span>YouTube</span></li>
        <li class="flex items-center space-x-2"><i class="fab fa-telegram-plane text-sky-500"></i> <span>Telegram</span></li>
        <li class="flex items-center space-x-2"><i class="fab fa-twitter text-blue-400"></i> <span>Twitter</span></li>
      </ul>
    </div>

    <!-- Getting Started -->
    <div>
      <h3 class="font-semibold text-black mb-2">Getting Started</h3>
      <ul class="space-y-2">
        <li><a href="#" class="hover:underline">Our Story</a></li>
        <li><a href="#" class="hover:underline">Scent Discovery Quiz</a></li>
        <li><a href="#" class="hover:underline">Shipping & Returns</a></li>
        <li><a href="#" class="hover:underline">Gift Cards</a></li>
      </ul>
    </div>

    <!-- Explore -->
    <div>
      <h3 class="font-semibold text-black mb-2">Explore</h3>
      <ul class="space-y-2">
        <li><a href="#" class="hover:underline">Signature Collections</a></li>
        <li><a href="#" class="hover:underline">Limited Editions</a></li>
        <li><a href="#" class="hover:underline">Seasonal Scents</a></li>
        <li><a href="#" class="hover:underline">Gift Sets</a></li>
      </ul>
    </div>

    <!-- Community -->
    <div>
      <h3 class="font-semibold text-black mb-2">Community</h3>
      <ul class="space-y-2">
        <li><a href="#" class="hover:underline">Discussion Forums</a></li>
        <li><a href="#" class="hover:underline">Reviews & Testimonials</a></li>
        <li><a href="#" class="hover:underline">Influencer Collaborations</a></li>
        <li><a href="#" class="hover:underline">Code of Conduct</a></li>
      </ul>
    </div>
  </div>

  <!-- Bottom Bar -->
  <div class="border-t border-gray-200 py-4 mt-6 px-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
    <span>&copy; <?= date('Y') ?> LUXE AROMAS. All rights reserved.</span>
    <div class="flex space-x-3 mt-3 md:mt-0">
      <i class="fab fa-cc-visa text-xl"></i>
      <i class="fab fa-cc-paypal text-xl"></i>
      <i class="fab fa-cc-stripe text-xl"></i>
      <i class="fas fa-shield-alt text-xl"></i>
    </div>
  </div>
</footer>
