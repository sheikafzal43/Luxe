<aside class="w-64 bg-white shadow-md min-h-screen px-6 py-8 font-sans text-sm border-r">
  <h2 class="text-2xl font-bold text-gray-800 mb-10">Dashboard</h2>

  <nav class="space-y-3 text-gray-700">
    <a href="index.php?page=profile"
       class="block px-4 py-2 rounded-lg hover:bg-gray-100 <?= ($_GET['page'] ?? '') === 'profile' ? 'bg-[#0F172A] text-white font-semibold' : '' ?>">
      My Profile
    </a>

    <a href="index.php?page=cart"
       class="block px-4 py-2 rounded-lg hover:bg-gray-100 <?= ($_GET['page'] ?? '') === 'cart' ? 'bg-[#0F172A] text-white font-semibold' : '' ?>">
      My Cart
    </a>

    <a href="index.php?page=wishlist"
       class="block px-4 py-2 rounded-lg hover:bg-gray-100 <?= ($_GET['page'] ?? '') === 'wishlist' ? 'bg-[#0F172A] text-white font-semibold' : '' ?>">
      My Wishlist
    </a>

    <a href="index.php?page=myOrders"
       class="block px-4 py-2 rounded-lg hover:bg-gray-100 <?= ($_GET['page'] ?? '') === 'myOrders' ? 'bg-[#0F172A] text-white font-semibold' : '' ?>">
      My Orders
    </a>

    <a href="index.php?page=changePassword"
       class="block px-4 py-2 rounded-lg hover:bg-gray-100 <?= ($_GET['page'] ?? '') === 'changePassword' ? 'bg-[#0F172A] text-white font-semibold' : '' ?>">
      Change Password
    </a>
  </nav>
</aside>
