<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
?>

<header class="bg-white shadow relative z-50">
  <div class="container mx-auto px-6 py-4 flex justify-between items-center">
    <h1 class="text-2xl font-bold text-gray-900">LUXE AROMAS</h1>

    <!-- Hamburger Icon -->
    <button id="hamburger" class="md:hidden text-2xl text-gray-800 focus:outline-none">
      <i class="fas fa-bars"></i>
    </button>

    <!-- Desktop Nav -->
    <nav id="navLinks" class="hidden md:flex space-x-6 text-gray-700 font-medium">
      <a href="index.php?page=home" class="hover:text-black">Home</a>
      <a href="index.php?page=men" class="hover:text-black">Men</a>
      <a href="index.php?page=women" class="hover:text-black">Women</a>
      <a href="index.php?page=brands" class="hover:text-black">Brands</a>
      <a href="index.php?page=about" class="hover:text-black">About Us</a>
    </nav>

    <!-- User Actions -->
    <div class="hidden md:flex space-x-4 items-center">
      <?php if (isset($_SESSION['user'])): ?>
        <a href="index.php?page=profile" title="My Profile">
          <i class="fas fa-user text-gray-700 text-xl"></i>
        </a>
        <a href="index.php?page=cart" title="Cart">
          <i class="fas fa-shopping-cart text-gray-700 text-xl"></i>
        </a>
        <form action="index.php" method="POST" class="inline">
          <button type="submit" name="logout" class="text-sm text-red-500 ml-4 hover:underline">
            Logout
          </button>
        </form>
      <?php else: ?>
        <a href="index.php?page=customerLogin" class="bg-black text-white px-4 py-2 rounded text-sm">Login</a>
        <a href="index.php?page=customerRegister" class="border border-black text-black px-4 py-2 rounded text-sm">Register</a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Mobile Nav -->
  <div id="mobileMenu" class="md:hidden hidden px-6 pb-4 bg-white border-t">
    <nav class="space-y-2 text-gray-700 font-medium">
      <a href="index.php?page=home" class="block hover:text-black">Home</a>
      <a href="index.php?page=men" class="block hover:text-black">Men</a>
      <a href="index.php?page=women" class="block hover:text-black">Women</a>
      <a href="index.php?page=brands" class="block hover:text-black">Brands</a>
      <a href="index.php?page=about" class="block hover:text-black">About Us</a>

      <div class="pt-4 border-t mt-4">
        <?php if (isset($_SESSION['user'])): ?>
          <a href="index.php?page=profile" class="block text-sm">👤 My Profile</a>
          <a href="index.php?page=cart" class="block text-sm">🛒 My Cart</a>
          <form action="index.php" method="POST" class="mt-2">
            <button type="submit" name="logout" class="text-red-500 hover:underline text-sm">
              Logout
            </button>
          </form>
        <?php else: ?>
          <a href="index.php?page=customerLogin" class="block bg-black text-white px-4 py-2 rounded text-center text-sm">Login</a>
          <a href="index.php?page=customerRegister" class="block mt-2 border border-black text-black px-4 py-2 rounded text-center text-sm">Register</a>
        <?php endif; ?>
      </div>
    </nav>
  </div>

  <!-- JavaScript to toggle menu -->
  <script>
    document.getElementById("hamburger").addEventListener("click", function () {
      const menu = document.getElementById("mobileMenu");
      menu.classList.toggle("hidden");
    });
  </script>
</header>
