<?php
$currentPage = $_GET['page'] ?? '';
?>

<aside class="w-64 min-h-screen bg-white shadow-lg px-6 py-8 flex flex-col justify-between font-sans transition-all duration-300 ease-in-out">

  <!-- Brand -->
  <div>
    <h2 class="text-2xl font-extrabold text-[#0F172A] mb-10 tracking-wide hover:scale-105 transition duration-200">
      LUXE AROMAS
    </h2>

    <nav class="space-y-4">
      <a href="index.php?page=adminDashboard"
         class="block px-4 py-2 rounded-lg <?= $currentPage === 'adminDashboard' ? 'bg-[#0F172A] text-white' : 'text-[#0F172A] hover:bg-gray-100' ?> transition duration-200">
        📊 Dashboard
      </a>

      <a href="index.php?page=adminProducts"
         class="block px-4 py-2 rounded-lg <?= $currentPage === 'adminProducts' ? 'bg-[#0F172A] text-white' : 'text-[#0F172A] hover:bg-gray-100' ?> transition duration-200">
        🛍️ Manage Products
      </a>

      <a href="index.php?page=adminUsers"
         class="block px-4 py-2 rounded-lg <?= $currentPage === 'adminUsers' ? 'bg-[#0F172A] text-white' : 'text-[#0F172A] hover:bg-gray-100' ?> transition duration-200">
        👥 Manage Users
      </a>

      <a href="index.php?page=adminOrders"
         class="block px-4 py-2 rounded-lg <?= $currentPage === 'adminOrders' ? 'bg-[#0F172A] text-white' : 'text-[#0F172A] hover:bg-gray-100' ?> transition duration-200">
        📦 Manage Orders
      </a>
    </nav>
  </div>

  <!-- Footer -->
  <div class="space-y-4">
    <a href="index.php?page=home"
       class="block bg-black text-white px-4 py-2 rounded-lg text-center font-semibold hover:bg-gray-900 transition duration-200 relative">
      View Site
      <span class="absolute right-4 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-green-400 rounded-full animate-ping"></span>
    </a>

    <form method="POST" action="index.php">
      <button name="logout"
              class="w-full bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition duration-200 font-semibold">
        🚪 Logout
      </button>
    </form>
  </div>
</aside>
