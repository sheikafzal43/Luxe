<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php?page=adminLogin");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Orders - Admin</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 font-sans text-gray-900">

  

  <div class="flex">
    <!-- ✅ Sidebar -->
    <?php include_once __DIR__ . '/../components/admin_sidebar.php'; ?>

    <!-- ✅ Main Content -->
    <main class="flex-1 px-10 py-12">
      <h1 class="text-3xl font-bold mb-8">Manage Orders</h1>

      <div class="overflow-x-auto bg-white p-6 rounded shadow">
        <?php if (empty($orders)): ?>
          <p class="text-gray-600">No orders found.</p>
        <?php else: ?>
          <table class="min-w-full text-sm">
            <thead class="text-left bg-gray-100">
              <tr>
                <th class="p-2">Order ID</th>
                <th class="p-2">Customer</th>
                <th class="p-2">Product</th>
                <th class="p-2">Quantity</th>
                <th class="p-2">Status</th>
                <th class="p-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($orders as $order): ?>
                <tr class="border-t">
                  <td class="p-2"><?= $order['id'] ?></td>
                  <td class="p-2"><?= htmlspecialchars($order['customer_name']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($order['product_name']) ?></td>
                  <td class="p-2"><?= $order['quantity'] ?></td>
                  <td class="p-2 font-semibold text-sm
                      <?= $order['status'] === 'Pending' ? 'text-yellow-600' : ($order['status'] === 'Confirmed' ? 'text-green-600' : 'text-red-600') ?>">
                    <?= $order['status'] ?>
                  </td>
                  <td class="p-2 space-x-2">
                    <?php if ($order['status'] === 'Pending'): ?>
                      <a href="index.php?page=adminOrders&action=update&id=<?= $order['id'] ?>&status=Confirmed"
                         class="text-green-600 hover:underline">Approve</a>
                      <a href="index.php?page=adminOrders&action=update&id=<?= $order['id'] ?>&status=Declined"
                         class="text-red-600 hover:underline">Decline</a>
                    <?php else: ?>
                      <span class="text-gray-500">No Actions</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </main>
  </div>

  
</html>
