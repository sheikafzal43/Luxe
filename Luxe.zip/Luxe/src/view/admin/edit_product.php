<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php?page=adminLogin");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Product - Admin Panel</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>

<body class="flex">
  <?php include_once __DIR__ . '/../components/admin_sidebar.php'; ?>

  <main class="flex-1 bg-gray-50 p-10">
    <h1 class="text-3xl font-bold mb-6">Edit Product</h1>

    <form action="index.php?page=adminProducts&action=update&id=<?= $product['id'] ?>" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow space-y-6 max-w-2xl">
      
      <div>
        <label class="block font-medium mb-1">Product Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" class="w-full border p-2 rounded" required>
      </div>

      <div>
        <label class="block font-medium mb-1">Price</label>
        <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($product['price']) ?>" class="w-full border p-2 rounded" required>
      </div>

      <div>
        <label class="block font-medium mb-1">Description</label>
        <textarea name="description" rows="4" class="w-full border p-2 rounded"><?= htmlspecialchars($product['description']) ?></textarea>
      </div>

      <div>
        <label class="block font-medium mb-1">Category</label>
        <select name="category" class="w-full border p-2 rounded" required>
          <option value="Men" <?= $product['category'] === 'Men' ? 'selected' : '' ?>>Men</option>
          <option value="Women" <?= $product['category'] === 'Women' ? 'selected' : '' ?>>Women</option>
        </select>
      </div>

      <div>
        <label class="block font-medium mb-1">Image</label>
        <?php if (!empty($product['image'])): ?>
          <img src="uploads/<?= htmlspecialchars($product['image']) ?>" class="w-20 h-20 object-contain mb-2" alt="product">
        <?php endif; ?>
        <input type="file" name="image">
      </div>

      <button type="submit" class="bg-black text-white px-6 py-2 rounded hover:bg-gray-800">Update Product</button>
    </form>
  </main>
</body>
</html>
