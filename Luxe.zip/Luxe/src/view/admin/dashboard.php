<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin'])) {
    header("Location: index.php?page=adminLogin");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard - Luxe Aromas</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-900 font-sans">

  <div class="flex">
    <!-- ✅ Sidebar -->
    <?php include_once __DIR__ . '/../components/admin_sidebar.php'; ?>

    <!-- ✅ Main Content -->
    <main class="flex-1 p-10">
      <h1 class="text-3xl font-bold mb-2">LUXE AROMAS Admin Dashboard</h1>
      <p class="text-gray-500 mb-8">Overview of LUXE AROMAS</p>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white shadow rounded p-6 text-center">
          <p class="text-gray-500 mb-2">Registered Users</p>
          <h2 class="text-3xl font-bold"><?= $userCount ?></h2>
          <p class="mt-1 text-sm text-gray-600">Total Registered Users</p>
        </div>

        <div class="bg-white shadow rounded p-6 text-center">
          <p class="text-gray-500 mb-2">Total Products</p>
          <h2 class="text-3xl font-bold"><?= $productCount ?></h2>
          <p class="mt-1 text-sm text-gray-600">Products Available</p>
        </div>

        <div class="bg-white shadow rounded p-6 text-center">
          <p class="text-gray-500 mb-2">Total Orders</p>
          <h2 class="text-3xl font-bold"><?= $orderCount ?></h2>
          <p class="mt-1 text-sm text-gray-600">Orders Placed</p>
        </div>

        <div class="bg-white shadow rounded p-6 text-center">
          <p class="text-gray-500 mb-2">Total Sales</p>
          <h2 class="text-3xl font-bold text-green-500">$<?= number_format($confirmedSales, 2) ?></h2>
          <p class="mt-1 text-sm text-gray-600">Confirmed Sales</p>
        </div>
      </div>
    </main>
  </div>

  
</body>
</html>
