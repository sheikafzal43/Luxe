<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php?page=adminLogin");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Products - Admin Panel</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="flex min-h-screen bg-gray-100">
  
  <?php include_once __DIR__ . '/../components/admin_sidebar.php'; ?>

  <main class="flex-1 p-8">
    <h1 class="text-3xl font-bold mb-6">Manage Products</h1>

    <!-- Add Product Section -->
    <section class="bg-white p-6 rounded shadow mb-10">
      <h2 class="text-xl font-semibold mb-4">Add New Product</h2>
      <form action="index.php?page=adminProducts&action=add" method="POST" enctype="multipart/form-data" class="space-y-6">
        <input type="text" name="name" placeholder="Product Name" class="w-full p-2 border rounded" required>
        
        <div>
          <label class="block mb-1">Price</label>
          <input type="number" name="price" step="0.01" placeholder="$ 0.00" class="w-full p-2 border rounded" required>
        </div>

        <div>
          <label class="block mb-1">Description</label>
          <textarea name="description" placeholder="Description" class="w-full p-2 border rounded" rows="4"></textarea>
        </div>

        <div>
          <label class="block mb-1">Image</label>
          <input type="file" name="image" class="mb-2">
        </div>

        <div>
          <label class="block mb-2">Category</label>
          <label><input type="radio" name="category" value="Men" required> Men</label>
          <label class="ml-6"><input type="radio" name="category" value="Women"> Women</label>
        </div>

        <button type="submit" class="w-full bg-black text-white py-2 rounded">Add Product</button>
      </form>
    </section>

    <!-- Product List Section -->
    <section class="bg-white p-6 rounded shadow">
      <h2 class="text-xl font-semibold mb-4">All Products</h2>
      <table class="w-full text-left text-sm border">
        <thead class="bg-gray-100">
          <tr>
            <th class="px-4 py-2">ID</th>
            <th class="px-4 py-2">Name</th>
            <th class="px-4 py-2">Price</th>
            <th class="px-4 py-2">Category</th>
            <th class="px-4 py-2">Description</th>
            <th class="px-4 py-2">Image</th>
            <th class="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($products as $product): ?>
            <tr class="border-t">
              <td class="px-4 py-2"><?= $product['id'] ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($product['name']) ?></td>
              <td class="px-4 py-2">$<?= number_format($product['price'], 2) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($product['category']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($product['description']) ?></td>
              <td class="px-4 py-2">
                <?php if (!empty($product['image'])): ?>
                  <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="Product Image" class="w-10 h-10 object-contain">
                <?php else: ?>
                  <span class="text-gray-400 italic">No image</span>
                <?php endif; ?>
              </td>
              <td class="px-4 py-2 space-x-2">
                <a href="index.php?page=adminProducts&action=edit&id=<?= $product['id'] ?>" class="text-blue-600 hover:underline">Edit</a>
                <a href="index.php?page=adminProducts&action=delete&id=<?= $product['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </main>
</body>
</html>
