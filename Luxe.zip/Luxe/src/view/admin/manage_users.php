<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php?page=adminLogin");
    exit;
}
?>




<?php
// ✅ Show any hidden PHP errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users - Admin Panel</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>

<body class="flex">
  <?php include_once __DIR__ . '/../components/admin_sidebar.php'; ?>

  <main class="flex-1 bg-gray-50 p-10">
    <h1 class="text-3xl font-bold mb-6">Manage Users</h1>

    <div class="bg-white p-6 rounded shadow overflow-x-auto">
      <table class="min-w-full table-auto text-sm">
        <thead class="bg-gray-100 text-gray-700">
          <tr>
            <th class="px-4 py-2 text-left">ID</th>
            <th class="px-4 py-2 text-left">Name</th>
            <th class="px-4 py-2 text-left">Email</th>
            <th class="px-4 py-2 text-left">Registered At</th>
            <th class="px-4 py-2 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
            <tr class="border-t">
              <td class="px-4 py-2"><?= $user['id'] ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($user['name']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($user['email']) ?></td>
              <td class="px-4 py-2"><?= $user['created_at'] ?></td>
              <td class="px-4 py-2">
                <a href="index.php?page=adminUsers&action=delete&id=<?= $user['id'] ?>" class="text-red-500 hover:underline">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</body>
</html>
