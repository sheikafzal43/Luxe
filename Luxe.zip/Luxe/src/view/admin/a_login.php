<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <link href="/LUXE/src/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">

  <!-- ✅ Updated form action -->
  <form action="index.php?page=adminLogin" method="POST" class="bg-white p-8 rounded-lg shadow-md w-96">
    <h2 class="text-2xl font-bold mb-6 text-center">Admin Login</h2>

    <label class="block mb-4">
      <span class="text-gray-700">Username</span>
      <input type="text" name="username" required class="w-full px-4 py-2 mt-1 border rounded-md">
    </label>

    <label class="block mb-6">
      <span class="text-gray-700">Password</span>
      <input type="password" name="password" required class="w-full px-4 py-2 mt-1 border rounded-md">
    </label>

    <button type="submit" class="w-full bg-gray-800 text-white py-2 rounded hover:bg-black">Login</button>
  </form>

</body>
</html>
